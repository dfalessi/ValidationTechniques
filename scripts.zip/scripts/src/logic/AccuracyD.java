package logic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.VotedPerceptron;
import weka.classifiers.lazy.IB1;
import weka.classifiers.lazy.IBk;
import weka.classifiers.misc.HyperPipes;
import weka.classifiers.misc.VFI;
import weka.classifiers.trees.J48;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.StringToNominal;

public class AccuracyD {
	public static void main (String args []) throws Exception
	{
		long startTime = System.nanoTime();
	    File resFile = new File("/home/jacky/weka/results/RQ3-Accuracy on D.csv");
	    resFile.delete();
	    //System.setOut(new PrintStream(new FileOutputStream("output.txt")));
	    File [] listOfCSV = new File ("/home/jacky/weka/Datasets/").listFiles();
	    for (File f : listOfCSV)
	    {
	    	//System.out.println(f.toString());
	    	if (f.toString().equals("/home/jacky/weka/Datasets/velocity.csv") || 
	    			f.toString().equals("/home/jacky/weka/Datasets/poi.csv"))
	    	{
	    		//CSV to ARFF conversion requires to change attribute type from String to Numeric
	    		csv2arff(f, true);
	    	}
	    	else
	    	{
	    		//regular CSV to ARFF conversion
	    		csv2arff(f);
	    	}	
		}
		
	    PrintWriter out = new PrintWriter(new FileOutputStream(new File("/home/jacky/weka/results/RQ3-Accuracy on D.csv"), true));
	    out.write(buildHeader());
	    out.close();
			
	    File [] listOfARFF = new File ("/home/jacky/weka/modifiedDatasets/").listFiles();
	    Arrays.sort(listOfARFF);
	    String [] listOfModel = {"RandomForest", "Logistic", "NaiveBayes", "J48", "IBk", "IB1", "VotedPerception", "VFI", "HyperPipes"};
	    
	    for (File f : listOfARFF)
	    {
	    	TechniqueRes res = null;
	    	String dataSetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("."));
			BufferedReader file = new BufferedReader(new FileReader(f.toString()));
	    	
	    	Instances data = new Instances(file);
	    	Instances dataA = seperateDataset(data, findLastRelease(data), true);
	    	dataA.setClassIndex(dataA.numAttributes() -1 );
	    	
	    	if (findNumVersions(dataA) > 1)
	    	{
		    	System.out.println("=====Running " + dataSetName);
	    		for (String model : listOfModel) 
	    		{ 
	    			res = Model(dataA, model);
	    			System.out.println("=====Done running " + model + " on " + dataSetName);
	    			out = new PrintWriter(new FileOutputStream(new File("/home/jacky/weka/results/RQ3-Accuracy on D.csv"), true));
	    			out.write(buildEntry(dataSetName, model, res.auc, res.precision, res.recall));
	    			out.close();
	    		}
	    	}
	    }	
	    long endTime = System.nanoTime();
	    System.out.println("Duration: " + TimeUnit.SECONDS.convert((endTime-startTime), TimeUnit.NANOSECONDS) + " Seconds");
	}
	   
	public static TechniqueRes Model(Instances data, String model) throws Exception
	{	
		Instances train = seperateDataset(data, findLastRelease(data), true);
		Instances test = seperateDataset(data, findLastRelease(data), false);
		//randomize the data
		train = removeAttribute(train);
		test = removeAttribute(test);
			
		train.randomize(new Random((int) System.currentTimeMillis()));

		Classifier c = null;
		//classifier
		switch (model)
		{
			case "RandomForest" :
				c = new weka.classifiers.trees.RandomForest();
				break;
			case "Logistic" :
				c = new Logistic();
				break;
			case "NaiveBayes" :
				c = new NaiveBayes();
				break;
			case "J48" :
				c = new J48();
				break;
			case "IBk" :
				c = new IBk();
				break;
			case "IB1" :
				c = new IB1();
				break;	
			case "VotedPerception" :
				c = new VotedPerceptron();
				break;
			case "VFI" :
				c = new VFI();
				break;
			case "HyperPipes" :
				c = new HyperPipes();
				break;
			default : 
				System.out.println("Invalid model");
		}
				
		c.buildClassifier(train);
		Evaluation ev = new Evaluation(train);
		ev.evaluateModel(c, test);
		
		return new TechniqueRes(ev.areaUnderROC(findPositiveClassIndex(data)), ev.precision(findPositiveClassIndex(data)), ev.recall(findPositiveClassIndex(data)));
	}

	 //convert CSV data set files to ARFF
	public static void csv2arff(File csv) throws Exception
	{
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(csv);
		Instances data = csvload.getDataSet();
				
		ArffSaver save = new ArffSaver();
		save.setInstances(data);
		String newFileName = "/home/jacky/weka/modifiedDatasets/" + csv.toString().substring(csv.toString().lastIndexOf("/")+1, csv.toString().lastIndexOf(".")) + ".arff";
		save.setFile(new File(newFileName));
		save.writeBatch();
	}
			
	//overloaded when CSV convert to ARFF results in String attribute type instead of numeric
	public static void csv2arff(File csv, boolean S) throws Exception
	{		
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(csv);
		Instances data = csvload.getDataSet();
		
		String [] opt = new String[2];
		opt[0] = "-R";
		opt[1] = "1";
		StringToNominal stn = new StringToNominal();
		stn.setOptions(opt);
		stn.setInputFormat(data);
		Instances tempData = Filter.useFilter(data, stn);
				
		ArffSaver save = new ArffSaver();
		save.setInstances(tempData);
		String newFileName = "/home/jacky/weka/modifiedDatasets/" + csv.toString().substring(csv.toString().lastIndexOf("/")+1, csv.toString().lastIndexOf(".")) + ".arff";
		save.setFile(new File(newFileName));
		save.writeBatch();
	}
		
	public static String buildHeader()
	{
		StringBuilder header = new StringBuilder();
		
		header.append("Dataset");
		header.append(',');
		header.append("Model");
		header.append(',');
		header.append("AUC");
		header.append(',');
		header.append("Precision");
		header.append(',');
		header.append("Recall");
		header.append('\n');
		
		return header.toString();
	}
	   
	public static String buildEntry(String dataset, String model, double auc, double pre, double rec)
	{
		StringBuilder entry = new StringBuilder();
		DecimalFormat numformat = new DecimalFormat("#.###");
		numformat.setRoundingMode(RoundingMode.UP);
		
		entry.append(dataset);
		entry.append(',');
		entry.append(model);
		entry.append(',');
		entry.append(numformat.format(auc));
		entry.append(',');
		entry.append(numformat.format(pre));
		entry.append(',');
		entry.append(numformat.format(rec));
		entry.append('\n');
		
		return entry.toString();
	}
	   
	public static String findLastRelease(Instances data)
	{	
		
		Instance n = data.instance(data.numInstances()-1);
		String latestRelease = n.toString(0);
		
		return latestRelease;
	}
	   
	public static Instances seperateDataset(Instances data, String version, boolean train)
	{
		Instances temp = new Instances(data, 0, data.numInstances());
		
		for (int i = data.numInstances() -1; i>=0; i--)
		{
			Instance n = temp.instance(i);
			if (train)
			{
				//train - true, remove version specified 
				if(n.toString(0).compareTo(version) == 0)
				{
					temp.delete(i);
				}
			}
			else
			{
				//train - false, remove version not specified
				if(n.toString(0).compareTo(version) != 0)
				{
					temp.delete(i);
				}
			}
		}
		return temp;
	}
	   
	public static Instances removeAttribute(Instances data) throws Exception
	{
		Remove removeFilter = new Remove();
		removeFilter.setAttributeIndices("1-1");
		removeFilter.setInputFormat(data);
		return Filter.useFilter(data, removeFilter);
	}

	public static int findPositiveClassIndex(Instances data)
	{
		int ind = 0;
		Attribute a = data.attribute(data.numAttributes()-1);
		String [] t = a.toString().split(" ");
		String last = t[t.length-1];
		
		if (last.equals("{FALSE,TRUE}"))
		{
			ind = 1;
		}
		return ind;
	}
	
	public static int findNumVersions(Instances data)
	{
		String currVersion = "";
		int num = 1;
		currVersion = data.firstInstance().toString(0);
		for (int i = 0; i < data.numInstances(); i++)
		{
			if (currVersion.compareTo(data.instance(i).toString(0)) != 0)
			{
				num++;
				currVersion = data.instance(i).toString(0);
			}
		}
		return num;
	}
}
