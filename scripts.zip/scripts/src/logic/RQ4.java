package logic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class RQ4 {
	
	final static int NUM_MODEL = 9;
	final static String [] listOfTechniques = {"Holdout 0.5", "Holdout 0.7", "Repeated Holdout 0.5", "Repeated Holdout 0.7", "2-fold", "10-fold", "10x10-fold", "Ordinary", "Optimism-reduced", "out-of-sample" , "0.632 Bootstrap", "Leave-one-release-out"};
	final static int NUM_TECHNIQUES = listOfTechniques.length;
	public static void main (String argv []) throws IOException
	{
		clearFiles();

		//compute bias
		File [] rq2FileList = new File ("/home/jacky/weka/Analyzed-Results/rq2-int").listFiles();
		Arrays.sort(rq2FileList);
		ArrayList<double [][]> tableList = new ArrayList<double [][]>();
		for (File f : rq2FileList)
		{
			String dataSetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("_")-2);
			if (tableList.size() < 2)
			{
				double [][] table = buildTable(f);
				tableList.add(table);
			}
			else
			{
				double [][] table = buildTable(f);
				tableList.add(table);
				computeBias(tableList, dataSetName);
				tableList.clear();
			}
		}
		
		//bias order 
		File [] rq4bias = new File ("/home/jacky/weka/Analyzed-Results/rq4-bias/").listFiles();
		Arrays.sort(rq4bias);
		for (File f : rq4bias)
		{
			biasOrder(f);
		}
		
		//order
		File [] rq4biasOrder = new File ("/home/jacky/weka/Analyzed-Results/rq4-bias-order/").listFiles();
		Arrays.sort(rq4biasOrder);
		for (File f : rq4biasOrder)
		{
			orderClassifiers(f);
		}
		
		//lost
		
			actualAUC();
		
	}
	
	public static void computeBias(ArrayList<double [][]> tableList, String dataSetName) throws IOException
	{
		System.out.println("Computing bias on: " + dataSetName);
		FileWriter fw = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq4-bias/" + dataSetName + "_bias_rq4.csv"), true);
		fw.append(buildHeader("computeBias"));
		double [][] tableA = tableList.get(0), tableP = tableList.get(1), tableR = tableList.get(2);
		double [] A = new double [NUM_MODEL], P = new double [NUM_MODEL], R = new double [NUM_MODEL];
		double biasA = 0.0, biasP = 0.0, biasR = 0.0;
		
		for (int i = 0; i < NUM_TECHNIQUES; i++)
		{
			for (int j = 0; j < NUM_MODEL; j++)
			{
				A[j] = Math.abs(tableA[j][i] - tableA[j][NUM_TECHNIQUES]);
				P[j] = Math.abs(tableP[j][i] - tableP[j][NUM_TECHNIQUES]);
				R[j] = Math.abs(tableR[j][i] - tableR[j][NUM_TECHNIQUES]);
			}
		biasA = calcAverage(A, NUM_MODEL);
		biasP = calcAverage(P, NUM_MODEL);
		biasR = calcAverage(R, NUM_MODEL);

		fw.write(buildEntry(dataSetName, listOfTechniques[i], biasA, biasP, biasR));
		}
		fw.close();
	}

	public static void biasOrder(File f) throws IOException
	{
		String dataSetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("_")-5);
		System.out.println("Ranking based on bias: " + dataSetName);
		BufferedReader br = new BufferedReader(new FileReader(f));
		boolean header = true;
		ArrayList<dataPoint> dataList = new ArrayList<dataPoint>();
		FileWriter fw = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq4-bias-order/" + dataSetName + "_bias_order_rq4.csv"), true);
		fw.append(buildHeader("biasOrder"));
		
		while(br.ready())
		{
			String [] temp = br.readLine().split(",");
			if(header)
			{
				header = false;
			}
			else
			{
				dataList.add(new dataPoint(temp[1], Double.valueOf(temp[2])));
			}
		}
		
		dataList.sort(new Comparator<dataPoint> () {

			//sort based on AUC bias, if equal sort by technique name
			@Override
			public int compare(dataPoint A, dataPoint B) {
				if (A.auc < B.auc)
				{
					return -1;
				}
				else if (A.auc > B.auc)
				{
					return 1;
				}
				return A.technique.compareTo(B.technique);
			}
		});
		
		for(dataPoint d : dataList)
		{
			fw.write(buildEntry(dataSetName, d.technique, d.auc));
		}
	
		fw.close();
		br.close();
	}

	public static void orderClassifiers(File f) throws IOException
	{
		String dataSetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("_")-11);
		System.out.println("Ranking based on both bias and actual orders: " + dataSetName);
		BufferedReader br = new BufferedReader(new FileReader(f));
		boolean header = true;
		ArrayList<dataPoint> actualOrder = getActualOrder(dataSetName);
		int ind = 0;
		
		FileWriter fw = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq4-order/" + dataSetName + "_order_rq4.csv"), true);
		fw.append(buildHeader("order"));
		
		while(br.ready())
		{
			String [] temp = br.readLine().split(",");
			if(header)
			{
				header = false;
			}
			else
			{
				fw.write(buildEntry(dataSetName, listOfTechniques[ind], temp[1], actualOrder.get(ind).technique));
				ind++;
			}
		}
		
		fw.close();
		br.close();
	}

	public static void actualAUC() throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader("/home/jacky/weka/Analyzed-Results/RQ2-final.csv"));
		boolean header = true;
		
		FileWriter fw = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq4-loss-AUC.csv"), true);
		fw.append(buildHeader("lossAUC"));
		
		while(br.ready())
		{
			String [] temp = br.readLine().split(",");
			if(header)
			{
				header = false;
			}
			else
			{
				String dataSetName = temp[0];
				double bias = best(temp, true);
				double actual = best(temp, false);
				fw.write(buildEntry(dataSetName, bias, actual));
			}
		}
		
		fw.close();
		br.close();
	}
	
	public static double [][] buildTable(File f) throws IOException
	{
		double [][] table = new double[NUM_MODEL][NUM_TECHNIQUES+1];
		BufferedReader br = new BufferedReader(new FileReader(f));
		boolean header = true;
		int row = 0;
		
		while (row < NUM_MODEL)
		{
			String [] temp = br.readLine().split(",");
			if (header)
			{
				header = false;
			}
			else if (!header)
			{
				for (int i = 0, j = 2; i<NUM_TECHNIQUES+1; i++, j++)
				{
					table[row][i] = Double.valueOf(temp[j]);
				}
				row++;
			}
		}	
		//System.out.println(Arrays.deepToString(table));
		br.close();
		return table;
	}
	
	public static ArrayList<dataPoint> getActualOrder(String dataSetName) throws IOException
	{
		System.out.println("Ordering based on AUC: " + dataSetName);
		String [] techniques = new String [NUM_TECHNIQUES]; 
		ArrayList<dataPoint> dataList = new ArrayList<dataPoint>();
		BufferedReader br = new BufferedReader(new FileReader("/home/jacky/weka/Analyzed-Results/RQ2-final.csv"));
		boolean header = true;
		while(br.ready())
		{
			String [] temp = br.readLine().split(",");
			if(header)
			{
				techniques = temp.clone();
				header = false;
			}
			else
			{
				if (temp[0].equals(dataSetName))
				{
					for(int i = 1; i < NUM_TECHNIQUES+1; i++)
					{
						dataList.add(new dataPoint(techniques[i], Double.valueOf(temp[i])));
					}
				}
			}
		}
		
		dataList.sort(new Comparator<dataPoint> () {
			//sort based on AUC bias, if equal sort by technique name
			@Override
			public int compare(dataPoint A, dataPoint B) {
				if (A.auc > B.auc)
				{
					return -1;
				}
				else if (A.auc < B.auc)
				{
					return 1;
				}
				return A.technique.compareTo(B.technique);
			}
		});
		
		br.close();
		return dataList;
	}
	
	public static String buildHeader(String type)
	{
		StringBuilder header = new StringBuilder();
		
		header.append("Dataset");
		header.append(',');
		switch(type)
		{
			case "computeBias": 
				header.append("Techniques,");
				header.append("AUC bias,");
				header.append("Precision bias,");
				header.append("Recall bias");
				break;
			case "biasOrder":
				header.append("Techniques,");
				header.append("Rank on Bias");
				break;
			case "order" :
				header.append("Techniques,");
				header.append("Rank Bias Order,");
				header.append("Rank Actual Order");
				break;
			case "lossAUC" :
				header.append("AUC selected by best technique,");
				header.append("AUC selected by lowest bias");
				break;
			default : 
				System.out.println("Invalid header type: " + type);
		}
		header.append("\n");
		
		return header.toString();
	}
	
	private static void clearFiles()
	{
		System.out.println("clearing out old files");
		File [] biasOrder = new File ("/home/jacky/weka/Analyzed-Results/rq4-bias-order/").listFiles();
		File [] bias = new File ("/home/jacky/weka/Analyzed-Results/rq4-bias/").listFiles();
		//File [] actualOrder = new File ("/home/jacky/weka/Analyzed-Results/rq4-actual-order/").listFiles();
		File [] order = new File ("/home/jacky/weka/Analyzed-Results/rq4-order/").listFiles();

		for (File f : biasOrder)
		{
			f.delete();
		}
		for (File f : bias)
		{
			f.delete();
		}
		for (File f : order)
		{
			f.delete();
		}
		
		File file = new File("/home/jacky/weka/Analyzed-Results/rq4-loss-AUC.csv");
        file.delete();
	}
	
	public static String buildEntry(String ds, String tch, double A, double P, double R)
	{
		StringBuilder entry = new StringBuilder();
		
		entry.append(ds);
		entry.append(',');
		entry.append(tch);
		entry.append(',');
		entry.append(A);
		entry.append(",");
		entry.append(P);
		entry.append(',');
		entry.append(R);
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static String buildEntry(String ds, String tch, double A)
	{
		StringBuilder entry = new StringBuilder();
		
		entry.append(ds);
		entry.append(',');
		entry.append(tch);
		entry.append(',');
		entry.append(A);
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static String buildEntry(String ds, String tch, String biasOrder, String actualOrder)
	{
		StringBuilder entry = new StringBuilder();
		
		entry.append(ds);
		entry.append(',');
		entry.append(tch);
		entry.append(',');
		entry.append(biasOrder);
		entry.append(',');
		entry.append(actualOrder);
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static String buildEntry(String ds, double bias, double actual)
	{
		StringBuilder entry = new StringBuilder();
		
		entry.append(ds);
		entry.append(',');
		entry.append(bias);
		entry.append(',');
		entry.append(actual);
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static double calcAverage(double [] res, int size)
	{
		double sum = 0.0;
		for (double d : res)
		{
			sum = sum+d;
		}
		return (sum/(double)size);
		
	}
	
	public static int findTechniqueInd(String source) 
	{
		for (int i = 0; i < NUM_TECHNIQUES; i++)
		{
			if (listOfTechniques[i].equals(source))
			{
				return i;
			}
		}
		return -1;
	}

	public static double best(String [] data, boolean bias) throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader("/home/jacky/weka/Analyzed-Results/rq4-order/" + data[0] + "_order_rq4.csv"));
		boolean header = true;
		double best = 0.0;
		while(br.ready())
		{
			String [] temp = br.readLine().split(",");
			if (header)
			{
				header = false;
			}
			else
			{
				if(bias)
				{
					double curr = Double.valueOf(data[findTechniqueInd(temp[2])+1]);
					if (curr > best)
					{
						best = curr;
					}
				}
				else
				{
					double curr = Double.valueOf(data[findTechniqueInd(temp[3])+1]);
					if (curr > best)
					{
						best = curr;
					}
				}
			}
			
		}
		br.close();
		return best;
	}
	
	public static class dataPoint
	{
		String technique;
		double auc;
		
		public dataPoint(String tech, double auc)
		{
			technique = tech;
			this.auc = auc;
		}
		
		public boolean equals(dataPoint other)
		{
			return this.technique.equals(other.technique) &&
					(this.auc == other.auc);
		}
	}
}
