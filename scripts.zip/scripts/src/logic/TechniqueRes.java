package logic;

public class TechniqueRes {
	
	public double auc;
	public double precision;
	public double recall;
	
	public TechniqueRes(double d, double e, double f)
	{
		this.auc = d;
		precision = e;
		recall = f;
	}
	
	public String toString()
	{
		return "AUC is" + auc + 
				"Precision is " + precision +
				"Recall is " + recall;
	}
}
