package logic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintWriter;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.VotedPerceptron;
import weka.classifiers.lazy.IBk;
import weka.classifiers.lazy.IB1;
import weka.classifiers.misc.HyperPipes;
import weka.classifiers.misc.VFI;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;
import weka.filters.Filter;
import weka.filters.supervised.instance.Resample;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.StringToNominal;

//RQ3 intermediate uses weka 3.7.1
public class Intermediate3 {
		public static void main (String args []) throws Exception
		{
			long startTime = System.nanoTime();
			File resFile = new File("/home/jacky/weka/results/RQ3-Intermediate.csv");
		    resFile.delete();
			//System.setOut(new PrintStream(new FileOutputStream("output.txt")));
			File [] listOfCSV = new File ("/home/jacky/weka/Datasets/").listFiles();
			/*for (File f : listOfCSV)
			{
				if (f.toString().equals("/home/jacky/weka/Datasets/velocity.csv") || 
						f.toString().equals("/home/jacky/weka/Datasets/poi.csv"))
				{
					//CSV to ARFF conversion requires to change attribute type from String to Numeric
					csv2arff(f, true);
				}
				else
				{
					//regular CSV to ARFF conversion
					csv2arff(f, false);
				}	
			}*/
		
			//3.7.1 has all models
			
			//name Dataset_(A/P/R)_Table name of the instruction excel file 
			// each data set has 3 tables, then we have RQ2 and RQ3 final 
			PrintWriter out = new PrintWriter(new FileOutputStream(new File("/home/jacky/weka/results/RQ3-Intermediate.csv"), true));
			out.write(buildHeader());
			out.close();
			
			File [] listOfARFF = new File ("/home/jacky/weka/modifiedDatasets/").listFiles();
		    Arrays.sort(listOfARFF);
			String [] listOfTechniques = {"Holdout 0.5", "Holdout 0.7", "Repeated Holdout 0.5", "Repeated Holdout 0.7", "2-fold", "10-fold", "10x10-fold", "Ordinary", "Optimism-reduced", "out-of-sample" , "0.632 Bootstrap", "Leave-one-release-out"};
			String [] listOfModel = {"RandomForest", "Logistic", "NaiveBayes", "J48", "IBk", "IB1", "VotedPerceptron", "VFI", "HyperPipes"};
			for (File f : listOfARFF)
			{
				for (String thq: listOfTechniques)
				{
					int iterations = 10;
					boolean leaveOneOut = false;
					int folds = 0;
					ArrayList<String> listOfVersions = new ArrayList<String>();
					TechniqueRes res = null;
			    	String dataSetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("."));
					BufferedReader file = new BufferedReader(new FileReader(f.toString()));
					Instances data = new Instances(file);
					Instances dataA = seperateDataset(data, findLastRelease(data), true);
					Instances dataC = seperateDataset(dataA, findLastRelease(data), true);
					listOfVersions = findNumVersions(dataC);
					dataC.setClassIndex(dataC.numAttributes() -1 );
					System.out.println("=====Running " + dataSetName);
					if (thq == "2-fold")
					{
						iterations = 2;
						folds = 2;
					}
					else if (thq == "10-fold")
					{
						folds = 10;
					}
					else if (thq == "10x10-fold")
					{
						folds = 10;
					}
					else if (thq == "Leave-one-release-out")
					{
						iterations = listOfVersions.size();
						leaveOneOut = true;
					}
					for (String model : listOfModel) 
					{
						res = Model(dataC, model, thq, dataSetName, iterations, leaveOneOut, folds, listOfVersions);
						out = new PrintWriter(new FileOutputStream(new File("/home/jacky/weka/results/RQ3-Intermediate.csv"), true));
						out.write(buildEntry(dataSetName, model, thq, res.auc, res.precision, res.recall));
						out.close();
					}
				}
			}
		 	long endTime = System.nanoTime();
		 	System.out.println("Duration: " + TimeUnit.SECONDS.convert((endTime-startTime), TimeUnit.NANOSECONDS) + " Seconds");
		}

		public static TechniqueRes Model(Instances data, String model, String technique, String dataSetName, int itr, boolean leaveOneOut, int folds, ArrayList<String> lstVerison) throws Exception
		{
			double auc = 0.0, pre = 0.0, re = 0.0;
			String version = "";
			double [] tempPre = new double [itr];
			double [] tempRe = new double [itr];
			double [] tempAuc = new double [itr];
			Evaluation ev2 = null;
			int fold = 0;
			
			Instances train = new Instances(data, -1);
			Instances test = new Instances(data, -1);
			
			for (int i = 0; i < itr; i++)
			{
				System.out.println("Dataset: " + dataSetName + " Model: " + model +  " Technique: " + technique + " Run # " + (i+1) + "/" + itr);
				if (technique == "2-fold" || technique == "10x10-fold" || technique == "10-fold")
				{
					if (technique == "2-fold")
						fold = 1;
					else if (technique == "10x10-fold" || technique == "10-fold" && fold == 0)
					{
						fold = 9;
					}
					train = data.trainCV(folds, fold);
					test = data.testCV(folds, fold);
					fold --;
				}
				else 
				{
					if (leaveOneOut)
					{
						version = lstVerison.get(i);
					}
					train = modifiyDataset(data, technique, i, version).train;
					test = modifiyDataset(data, technique, i, version).test;	
				}
			
				//remove version# from dataset
				train = removeAttribute(train);
				test = removeAttribute(test);
				
				
				train.randomize(new Random((int) System.currentTimeMillis()));

				Classifier c = null;
				//classifier
				switch (model)
				{
					case "RandomForest" :
						c = new RandomForest();
						break;
					case "Logistic" :
						c = new Logistic();
						break;
					case "NaiveBayes" :
						c = new NaiveBayes();
						break;
					case "J48" :
						c = new J48();
						break;
					case "IBk" :
						c = new IBk();
						break;
					case "IB1" :
						c = new IB1();
						break;	
					case "VotedPerceptron" :
						c = new VotedPerceptron();
						break;
					case "VFI" :
						c = new VFI();
						break;
					case "HyperPipes" :
						c = new HyperPipes();
						break;
					default : 
						System.out.println("Invalid model");
				}
				
				c.buildClassifier(train);
				Evaluation ev = new Evaluation(train);
				ev.evaluateModel(c, test);
				if (technique.compareTo("Optimism-reduced") == 0)
				{
					ev2 = new Evaluation(train);
					ev2.evaluateModel(c, removeAttribute(data)); //test on org data
					tempAuc[i] = ev.areaUnderROC(findPositiveClassIndex(train)) - ev2.areaUnderROC(findPositiveClassIndex(data));
					tempPre[i] = ev.precision(findPositiveClassIndex(train)) - ev2.precision(findPositiveClassIndex(data));
					tempRe[i] = ev.recall(findPositiveClassIndex(train)) - ev2.recall(findPositiveClassIndex(data));
					if (technique.compareTo("0.632 Bootstrap") == 0)
					{
						tempAuc[i] = (((0.368) * ev2.precision(findPositiveClassIndex(data))) + ((0.632) * ev.precision(findPositiveClassIndex(train))));
						tempPre[i] = (((0.368) * ev2.precision(findPositiveClassIndex(data))) + ((0.632) * ev.precision(findPositiveClassIndex(train))));
						tempRe[i] = (((0.368) * ev2.precision(findPositiveClassIndex(data))) + ((0.632) * ev.precision(findPositiveClassIndex(train))));
					}
				}
				else 
				{
					tempAuc[i] = ev.areaUnderROC(findPositiveClassIndex(train));
					tempPre[i] = ev.precision(findPositiveClassIndex(train));
					tempRe[i] = ev.recall(findPositiveClassIndex(train));
					//System.out.println(tempAuc[i]);
				}
			}
			
			//find the average
			if (technique.compareTo("Optimism-reduced") == 0)
			{
				auc = ev2.areaUnderROC(findPositiveClassIndex(data)) - findAverage(tempAuc, itr);
				pre = ev2.precision(findPositiveClassIndex(data)) - findAverage(tempPre, itr);
				re = ev2.recall(findPositiveClassIndex(data)) - findAverage(tempRe, itr);
			}
			else
			{
				auc = findAverage(tempAuc, itr);
				pre = findAverage(tempPre, itr);
				re = findAverage(tempRe, itr);
			}
			return new TechniqueRes(auc, pre, re);
		}
				
		//overloaded when CSV convert to ARFF results in String attribute type instead of numeric
		public static void csv2arff(File csv, boolean S) throws Exception
		{		
			CSVLoader csvload = new CSVLoader();
			csvload.setSource(csv);
			Instances data = csvload.getDataSet();
			
			String [] opt = new String[2];
			opt[0] = "-R";
			opt[1] = "1";
			StringToNominal stn = new StringToNominal();
			stn.setOptions(opt);
			stn.setInputFormat(data);
			Instances tempData = Filter.useFilter(data, stn);
					
			ArffSaver save = new ArffSaver();
			if(S)
			{
				save.setInstances(tempData);
			}
			else
			{
				save.setInstances(data);
			}
			String newFileName = "/home/jacky/weka/modifiedDatasets/" + csv.toString().substring(csv.toString().lastIndexOf("/")+1, csv.toString().lastIndexOf(".")) + ".arff";
			save.setFile(new File(newFileName));
			save.writeBatch();
		}
		
		public static Instances removeAttribute(Instances data) throws Exception
		{
			Remove removeFilter = new Remove();
			removeFilter.setAttributeIndices("1-1");
			removeFilter.setInputFormat(data);
			return Filter.useFilter(data, removeFilter);
		}
		
		public static String findLastRelease(Instances data)
		{	
			Instance n = data.instance(data.numInstances()-1);
			String latestRelease = n.toString(0);
			
			return latestRelease;
		}
		
		public static String buildEntry(String dataset, String model, String teh, double auc, double pre, double rec)
		{
			StringBuilder entry = new StringBuilder();
			DecimalFormat numformat = new DecimalFormat("#.###");
			numformat.setRoundingMode(RoundingMode.UP);
			
			entry.append(dataset);
			entry.append(',');
			entry.append(model);
			entry.append(',');
			entry.append(teh);
			entry.append(',');
			entry.append(numformat.format(auc));
			entry.append(',');
			entry.append(numformat.format(pre));
			entry.append(',');
			entry.append(numformat.format(rec));
			entry.append('\n');
			
			return entry.toString();
		}
		
		public static String buildHeader()
		{
			StringBuilder header = new StringBuilder();

			header.append("Dataset");
			header.append(',');
			header.append("Model");
			header.append(',');
			header.append("Technique");
			header.append(',');
			header.append("AUC");
			header.append(',');
			header.append("Precision");
			header.append(',');
			header.append("Recall");
			header.append('\n');
			
			return header.toString();
		}
		
		public static Instances seperateDataset(Instances data, String version, boolean train)
		{
			Instances temp = new Instances(data, 0, data.numInstances());
			//System.out.println("version specified to remove" + version);
			for (int i = data.numInstances() -1; i>=0; i--)
			{
				Instance n = temp.instance(i);
				if (train)
				{
					//train - true, remove version specified 
					if(n.toString(0).compareTo(version) == 0)
					{
						//System.out.println("train" + n.toString(0));
						temp.delete(i);
					}
				}
				else
				{
					//train - false, remove version not specified
					if(n.toString(0).compareTo(version) != 0)
					{
						//System.out.println("test" + n.toString(0));
						temp.delete(i);
					}
				}
			}
			return temp;
		}
		
		public static int findPositiveClassIndex(Instances data)
		{
			int ind = 0;
			Attribute a = data.attribute(data.numAttributes()-1);
			String [] t = a.toString().split(" ");
			String last = t[t.length-1];
			if (last.equals("{FALSE,TRUE}"))
			{
				ind = 1;
			}
			return ind;
		}
		
		public static void findBestValues(ArrayList<TechniqueRes> res, double [] best)
		{
			for (TechniqueRes tr : res)
			{
				if (tr.auc > best[0])
					best[0] = tr.auc;
				if (tr.precision > best[1])
					best[1] = tr.precision;
				if (tr.recall > best[2])
					best[2] = tr.recall;
			}
		}
		
		public static ArrayList<String> findNumVersions(Instances data)
		{
			String currVersion = "";
			ArrayList<String> temp = new ArrayList<String>();
			currVersion = data.firstInstance().toString(0);
			temp.add(currVersion);
			for (int i = 0; i < data.numInstances(); i++)
			{
				if (currVersion.compareTo(data.instance(i).toString(0)) != 0)
				{
					temp.add(data.instance(i).toString(0));
					currVersion = data.instance(i).toString(0);
				}
			}
			return temp;
		}
		
		public static Instances outOfSampleData(Instances data, Instances train)
		{
			Instances temp = new Instances(data, -1);
			for (int i = 0; i<data.numInstances(); i++)
			{
				if ((contains(train, data.get(i))) == false)
				{
					temp.add(data.get(i));
				}
			}
			return temp;
		}
		
		public static boolean contains(Instances data, Instance b) 
		{
			for (int i = 0; i< data.numInstances(); i++)
			{
				if (isSame(data.get(i), b) == true)
				{
					return true;
				}
			}
			return false;
		}
		
		public static boolean isSame(Instance a, Instance b)
		{
			for (int i = 0; i<a.numAttributes(); i++)
			{
				if (a.toString(i).compareTo(b.toString(i)) != 0)
				{
					return false;
				}
			}
			return true;
		}
			
		public static double findAverage(double [] res, int size)
		{
			double sum = 0.0;
			for (double d : res)
			{
				sum = sum+d;
			}
			return (sum/(double)size);
			
		}
		
		public static InstancesSet modifiyDataset (Instances data, String technique, int itr, String version) throws Exception
		{
			InstancesSet temp = null;
			Instances train = null, test = null;
			int numInstances = data.numInstances() , trainSize = 0, testSize = 0;
			Random rnd = new Random(System.currentTimeMillis());
			data.randomize(rnd);
			if (technique.compareTo("Holdout 0.5") == 0 || technique.compareTo("Repeated Holdout 0.5") == 0)
			{	
				trainSize = (int) Math.round(numInstances * 0.5);
				testSize = numInstances - trainSize;
				train = new Instances(data,0, trainSize);
				test = new Instances(data, trainSize,testSize);
				
			}
			else if (technique.compareTo("Holdout 0.7") == 0 || technique.compareTo("Repeated Holdout 0.7") == 0)
			{
				trainSize = (int) Math.round(numInstances * 0.7);
				testSize = numInstances - trainSize;
				train = new Instances(data, 0, trainSize);
				test = new Instances(data, trainSize, testSize);
			}
			else if (technique.compareTo("Ordinary") == 0 || technique.compareTo("Optimism-reduced") == 0 || technique.compareTo("0.632 Bootstrap") == 0)
			{
				trainSize = numInstances;
				test = data;
				Resample re = new Resample();
				re.setRandomSeed((int) System.currentTimeMillis());
				re.setInputFormat(data);
				train = Resample.useFilter(data, re);
			}
			else if (technique.compareTo("out-of-sample") == 0)
			{
				trainSize = numInstances;
				Resample re = new Resample();
				re.setNoReplacement(false);
				re.setRandomSeed((int) System.currentTimeMillis());
				re.setInputFormat(data);
				train = Resample.useFilter(data, re);
				test = outOfSampleData(data, train);
			}
			else if (technique.compareTo("Leave-one-release-out") == 0)
			{	
				train = seperateDataset(data, version, true);
				test = seperateDataset(data, version, false);
			}
			temp = new InstancesSet(train, test);
			return temp;
		}
}
