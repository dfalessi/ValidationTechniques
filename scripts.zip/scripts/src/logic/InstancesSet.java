package logic;

import weka.core.Instances;

public class InstancesSet {
	
	public Instances train;
	public Instances test;
	public InstancesSet (Instances train, Instances test)
	{
		this.train = train;
		this.test = test;
	}
}
