package logic;
//Requires WEKA 3.7.1

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;
import weka.filters.unsupervised.attribute.StringToNominal;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.VotedPerceptron;
import weka.classifiers.lazy.IB1;
import weka.classifiers.lazy.IBk;
import weka.classifiers.misc.VFI;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.*;

public class RQ1 {
	
	private static final String [] listOfClassifiers = {"RandomForest", "Logistic", "NaiveBayes", "J48", "IBk", "IB1", "VotedPerceptron", "VFI", "HyperPipes"};
	
	public static void main (String args []) throws Exception
	{
		long startTime = System.nanoTime();
		File res = new File("/home/jacky/weka/results/RQ1-Results.csv");
		res.delete();
		SimulationDataProcess.startDatasetProcess(false);
		System.setOut(new PrintStream(new FileOutputStream("RQ1-output.txt")));
		File [] listOfCSV = new File ("/home/jacky/weka/ProcessedDatasets/").listFiles();
		for (File f : listOfCSV)
		{
			//System.out.println(f.toString());
			if (f.toString().equals("/home/jacky/weka/ProcessedDatasets/velocity.csv") || 
				f.toString().equals("/home/jacky/weka/ProcessedDatasets/poi.csv"))
			{
				//CSV to ARFF conversion requires to change attribute type from String to Numeric
				csv2arff(f, true);
			}
			else
			{
				//regular CSV to ARFF conversion
				csv2arff(f);
			}
		}
				
		PrintWriter out = new PrintWriter(new FileOutputStream(new File("/home/jacky/weka/results/RQ1-Results.csv"), true));
   	 	out.write(buildHeader());
   	 	out.close();
   	 	
		File [] listOfARFF = new File ("/home/jacky/weka/modifiedDatasets/").listFiles();
		Arrays.sort(listOfARFF, new Comparator<File> () {

			@Override
			public int compare(File A, File B) {
				String dataSetNameA = A.toString().substring(A.toString().lastIndexOf("/")+1, A.toString().lastIndexOf("_"));
				String dataSetNameB = B.toString().substring(B.toString().lastIndexOf("/")+1, B.toString().lastIndexOf("_"));

				Integer numA = Integer.valueOf(A.toString().substring(A.toString().lastIndexOf("_")+1, A.toString().lastIndexOf(".")));
				Integer numB = Integer.valueOf(B.toString().substring(B.toString().lastIndexOf("_")+1, B.toString().lastIndexOf(".")));
				
				if (dataSetNameA.compareTo(dataSetNameB) == 0)
				{
					return numA.compareTo(numB);
				}
				return dataSetNameA.compareTo(dataSetNameB);
			}
		});
		long dataSetStartTime = System.nanoTime();
		ArrayList<String> outOfTimeList = new ArrayList<String>();
		for (File f : listOfARFF)
		{
			dataSetStartTime = System.nanoTime();
			String dataSetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("."));
			String XdataSetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("_"));
			BufferedReader file = new BufferedReader(new FileReader(f.toString()));
			Instances data = new Instances(file);
			data.setClassIndex(data.numAttributes() -1 );
			System.out.println("=====Running with " + dataSetName);
			for (String classifier : listOfClassifiers)
			{
				if (outOfTimeList.contains(XdataSetName))
				{
					System.out.println(XdataSetName + "skipping");
					//do nothing the dataset is pass the time 
				}
				else 
				{
					compute(data, dataSetName, classifier);
					if (TimeUnit.HOURS.convert((System.nanoTime()-dataSetStartTime), TimeUnit.NANOSECONDS) > 24)
					{
						System.out.println("adding" + XdataSetName);
						outOfTimeList.add(XdataSetName);
					}				
				}
			}
			System.out.println("=====Done with " + dataSetName);
		}
		
   	 	long endTime = System.nanoTime();
   	 	System.out.println("Duration " + TimeUnit.SECONDS.convert((endTime-startTime), TimeUnit.NANOSECONDS) + " Seconds");
	}
	
	public static void compute(Instances data, String dataSetName, String classifier) throws Exception
	{
		System.out.println("Running " + classifier);
		//prep the data set by finding the last release
		//use all but the last release as train
		//use only the last release as test
		String latestRelease = findLastRelease(data);
		Instances tempTrain = modifyDataSet(data, latestRelease, true);
		Instances tempTest = modifyDataSet(data, latestRelease, false);

		//remove release attribute from the data set not useful
		Instances train = removeAttribute(tempTrain);
		Instances test = removeAttribute(tempTest);

		//randomize the data
		train.randomize(new Random((int) System.currentTimeMillis()));
				
		Evaluation ev = new Evaluation(train);
		//build and tune classifier
		try {
		switch (classifier)
		{
			case "RandomForest" :
				RandomForest rf = new RandomForest();
				
				rf.buildClassifier(train);
				ev.evaluateModel(rf, test);	
				break;
			case "Logistic" :
				Logistic log = new Logistic();
			
				log.buildClassifier(train);
				ev.evaluateModel(log, test);
				break;
			case "NaiveBayes" :
				NaiveBayes nb = new NaiveBayes();
				
				nb.buildClassifier(train);
				ev.evaluateModel(nb, test);
				break;
			case "J48" :
				J48 j = new J48();
				
				j.buildClassifier(train);
				ev.evaluateModel(j, test);
				break;
			case "IBk" :
				IBk ibk = new IBk();
				
				ibk.buildClassifier(train);
				ev.evaluateModel(ibk, test);
				break;
			case "IB1" :
				IB1 ib = new IB1();
				
				ib.buildClassifier(train);
				ev.evaluateModel(ib, test);
				break;	
			case "VotedPerceptron" :				
				VotedPerceptron vp = new VotedPerceptron();
				
				vp.buildClassifier(train);
				ev.evaluateModel(vp, test);
				break;
			case "VFI" :
				VFI v = new VFI();
				
				v.buildClassifier(train);
				ev.evaluateModel(v, test);				
				break;
			case "HyperPipes" :
				weka.classifiers.misc.HyperPipes hp = new weka.classifiers.misc.HyperPipes();
				
				hp.buildClassifier(train);
				ev.evaluateModel(hp, test);
				break;
			default : 
				System.out.println("Invalid classifier " + classifier);
		}
		} catch (Exception e)
		{
			//TODO find a better way to handle 
			System.out.println(dataSetName + "training or test set does not contain both class attributes");
		}
		
		PrintWriter out = new PrintWriter(new FileOutputStream(new File("/home/jacky/weka/results/RQ1-Results.csv"), true));
		out.write(buildEntry(ev, dataSetName, classifier, data));
		out.close();
	}
	

	//convert CSV data set files to ARFF
	public static void csv2arff(File csv) throws Exception
	{		
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(csv);
		Instances data = csvload.getDataSet();
		
		ArffSaver save = new ArffSaver();
		save.setInstances(data);
		String newFileName = "/home/jacky/weka/modifiedDatasets/" + csv.toString().substring(csv.toString().lastIndexOf("/")+1, csv.toString().lastIndexOf(".")) + ".arff";
		save.setFile(new File(newFileName));
		save.writeBatch();
	}
	
	//overloaded when CSV convert to ARFF results in String attribute type instead of numeric
	public static void csv2arff(File csv, boolean S) throws Exception
	{		
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(csv);
		Instances data = csvload.getDataSet();
		
		String [] opt = new String[2];
		opt[0] = "-R";
		opt[1] = "1";
		StringToNominal stn = new StringToNominal();
		stn.setOptions(opt);
		stn.setInputFormat(data);
		Instances tempData = Filter.useFilter(data, stn);
		
		ArffSaver save = new ArffSaver();
		save.setInstances(tempData);
		String newFileName = "/home/jacky/weka/modifiedDatasets/" + csv.toString().substring(csv.toString().lastIndexOf("/")+1, csv.toString().lastIndexOf(".")) + ".arff";
		save.setFile(new File(newFileName));
		save.writeBatch();
	}
	
	public static Instances removeAttribute(Instances data) throws Exception
	{
		Remove removeFilter = new Remove();
		removeFilter.setAttributeIndices("1-1");
		removeFilter.setInputFormat(data);
		return Filter.useFilter(data, removeFilter);
	}
	
	public static String findLastRelease(Instances data)
	{	
		Instance n = data.instance(data.numInstances()-1);
		String latestRelease = n.toString(0);
		
		return latestRelease;
	}
	
	public static String buildEntry(Evaluation e, String dataset, String model, Instances data)
	{
		StringBuilder entry = new StringBuilder();
		DecimalFormat numformat = new DecimalFormat("#.###");
		numformat.setRoundingMode(RoundingMode.UP);
		
		entry.append(dataset);
		entry.append(',');
		entry.append(model);
		entry.append(',');
		entry.append(numformat.format(e.areaUnderROC(findPositiveClassIndex(data))));
		entry.append(',');
		entry.append(numformat.format(e.precision(findPositiveClassIndex(data))));
		entry.append(',');
		entry.append(numformat.format(e.recall(findPositiveClassIndex(data))));
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static String buildHeader()
	{
		StringBuilder header = new StringBuilder();

		header.append("Dataset");
		header.append(',');
		header.append("Model");
		header.append(',');
		header.append("AUC");
		header.append(',');
		header.append("Precision");
		header.append(',');
		header.append("Recall");
		header.append('\n');
		
		return header.toString();
	}
	
	public static Instances modifyDataSet(Instances data, String version, boolean train)
	{
		Instances temp = new Instances(data, 0, data.numInstances());
		for (int i = temp.numInstances() -1; i>=0; i--)
		{
			Instance n = temp.instance(i);
			if (train)
			{
				//train - true, remove version specified 
				if(n.toString(0).equals(version))
				{
					temp.delete(i);
				}
			}
			else
			{
				//train - false, remove version not specified
				if(!(n.toString(0).equals(version)))
				{
					temp.delete(i);
				}
			}
		}
		return temp;
	}
	
	public static int findPositiveClassIndex(Instances data)
	{
		Attribute a = data.attribute(data.numAttributes()-1);
		String [] t = a.toString().split(" ");
		String last = t[t.length-1];
		
		if (last.toLowerCase().equals("{false,true}"))
		{
			return 1;
		}
		return 0;
	}
}
