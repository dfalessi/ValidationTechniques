package logic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class SortResults {
	
	public final static int NUM_MODEL = 9;
	public final static String [] listOfTechniques = {"Holdout 0.5", "Holdout 0.7", "Repeated Holdout 0.5", "Repeated Holdout 0.7", "2-fold", "10-fold", "10x10-fold", "Ordinary", "Optimism-reduced", "out-of-sample" , "0.632 Bootstrap", "Leave-one-release-out"};
	public final static int NUM_TECHNIQUES = listOfTechniques.length;
	
	public static void main (String args []) throws IOException
	{
		ArrayList<dataPoint> rq1 = buildData(new BufferedReader(new FileReader("/home/jacky/weka/results/RQ1-Results.csv")));
		Collections.sort(rq1);
		ArrayList<dataPoint> rq2 = buildData(new BufferedReader(new FileReader("/home/jacky/weka/results/RQ2-Results.csv")));	
		Collections.sort(rq2);
		//ArrayList<dataPoint> rq3 = buildData(parseFile("/home/jacky/weka/results/RQ3-Intermediate.csv"));	
		//Collections.sort(rq3);
		//ArrayList<dataPoint> rq3CD = buildData(parseFile("/home/jacky/weka/results/RQ3-Accuracy on D.csv"));	
		//Collections.sort(rq3CD);

		int numDatasets = rq2.size()/(NUM_TECHNIQUES * NUM_MODEL);
		clearFiles();
				
		for (int i = 0; i< numDatasets; i++)
		{
			processRQint(rq1, rq2, i, true);
			System.out.println("rq2int: " + (i+1) + "/" + numDatasets);
		}
		
		FileWriter fwF = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/RQ2-final.csv"), true);
		fwF.append(buildHeader("rq2final"));
		fwF.close();
		File [] rq2FileList = new File ("/home/jacky/weka/Analyzed-Results/rq2-int").listFiles();
		for (File f : rq2FileList)
		{	
			if (f.getName().contains("_A_"))
			{
				processRQ2final(f);
				System.out.println("===rq2final done with " + f.toString().substring(f.toString().lastIndexOf("/")+1) + "===");
			}		
		}
		
		processRQ2FinalRanked();
		
		/*for (int i = 0; i< numDatasets; i++)
		{
			processRQint(rq3CD, rq3, i, false);
			System.out.println("rq3int: " + (i+1) + "/" + numDatasets);
		}*/
		
		/*for (File f : rq2FileList)
		{
			processRQ3uns(f);
			System.out.println("===rq3uns done with " + f.toString().substring(f.toString().lastIndexOf("/")+1) + "===");
		}*/
		
		//FileWriter fwF3 = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/RQ3-final.csv"), true);
		//fwF3.append(buildHeader("rq3final"));
		//fwF3.close();

		//File [] rq3FileList = new File ("/home/jacky/weka/Analyzed-Results/rq3-int").listFiles();
		//String [][] bestTechniqueTable = fillBestTechniqueTable(rq3FileList, numDatasets);
		//System.out.println("===done with rq3-int-best.csv===");
		
		/*File [] rq3unsFileList = new File ("/home/jacky/weka/Analyzed-Results/rq3-uns").listFiles();
		for (File f : rq3unsFileList)
		{
			if (f.getName().contains("_A_"))
			{
				processRQ3final(f, bestTechniqueTable);
				System.out.println("===rq3final done with " + f.toString().substring(f.toString().lastIndexOf("/")+1) + "===");
			}	
		}*/
	}
	
	public static ArrayList<dataPoint> buildData(BufferedReader br) throws IOException
	{
		boolean header, rq1 = false;
		ArrayList<dataPoint> res = new ArrayList<dataPoint>();
		while (br.ready())
		{
			String [] temp = br.readLine().split(",");
			header = false;
			if (temp[0].equals("Dataset"))
			{
				header = true;
				if (temp[4].equals("Recall"))
					rq1 = true;
			}
			if (!header)
			{
				if (rq1)
				{
					for (int x = 2; x < temp.length; x ++)
					{
						try {
							Double.valueOf(temp[x]);
						} catch (NumberFormatException e) {
							temp[x] = "0";
						}
					}
					res.add(new dataPoint(temp[0], temp[1], Double.valueOf(temp[2]), Double.valueOf(temp[3]), Double.valueOf(temp[4])));
				}
				else 
				{
					for (int x = 3; x < temp.length; x ++)
					{
						try {
							Double.valueOf(temp[x]);
						} catch (NumberFormatException e) {
							temp[x] = "0";
						}
					}
					res.add(new dataPoint(temp[0], temp[1], temp[2], Double.valueOf(temp[3]), Double.valueOf(temp[4]), Double.valueOf(temp[5])));
				}
			}
		}
		return res;
	}
	
	public static void processRQint(ArrayList<dataPoint>L1, ArrayList<dataPoint>L2, int dataIndex, boolean rq2) throws IOException
	{
		int currInd = 0, offSet = NUM_TECHNIQUES * NUM_MODEL * dataIndex;
		double [] valA = new double [NUM_TECHNIQUES], valP = new double [NUM_TECHNIQUES], valR = new double [NUM_TECHNIQUES];
		
		FileWriter fwA = null, fwP = null, fwR = null;
		if (rq2)
		{
			fwA = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq2-int/" + L2.get(offSet).datasetName + "_A_Rq2-int.csv"), true);
			fwA.append(buildHeader("rq2int"));
			fwP = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq2-int/" + L2.get(offSet).datasetName  + "_P_Rq2-int.csv"), true);
			fwP.append(buildHeader("rq2int"));
			fwR = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq2-int/" + L2.get(offSet).datasetName  + "_R_Rq2-int.csv"), true);
			fwR.append(buildHeader("rq2int"));
		}
		else if (!rq2)
		{
			fwA = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq3-int/" + L2.get(offSet).datasetName + "_A_Rq3-int-best.csv"), true);
			fwA.append(buildHeader("rq3int"));
			fwP = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq3-int/" + L2.get(offSet).datasetName  + "_P_Rq3-int-best.csv"), true);
			fwP.append(buildHeader("rq3int"));
			fwR = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq3-int/" + L2.get(offSet).datasetName  + "_R_Rq3-int-best.csv"), true);
			fwR.append(buildHeader("rq3int"));
		}
		
		while(currInd < NUM_MODEL)
		{
			dataPoint currDP = L2.get(offSet + currInd);
			
			for (int i = offSet + currInd, j = 0; i < (NUM_TECHNIQUES * NUM_MODEL + offSet); i = i + NUM_TECHNIQUES - 3 , j++)
			{
				valA[j] = L2.get(i).auc;
				valP[j] = L2.get(i).precision;
				valR[j] = L2.get(i).recall;	

			}
			
			dataPoint rq1DP = findDP(L1, currDP);
			
			fwA.append(buildEntry(currDP, valA, rq1DP.auc));
			fwP.append(buildEntry(currDP, valP, rq1DP.precision));
			fwR.append(buildEntry(currDP, valR, rq1DP.recall));
		
			currInd++;
			valA = new double [NUM_TECHNIQUES];
			valP = new double [NUM_TECHNIQUES];
			valR = new double [NUM_TECHNIQUES];
		}
		
		fwA.close();
		fwP.close();
		fwR.close();
	}
	
	public static void processRQ3uns(File f) throws IOException
	{
		double [][] rq2table = buildTable(f);
		char type = 'A';
		double sum = 0.0, mean = 0.0, median = 0.0, auc = 0.0;
		String datasetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("_")-2);
		BufferedReader br = new BufferedReader(new FileReader(f));

		if(f.getName().contains("_P_"))
		{
			type = 'P';
		} else if (f.getName().contains("_R_"))
		{
			type = 'R';
		}
		String header = br.readLine();
		FileWriter fw = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/rq3-uns/" + datasetName +"_" + type + "_Rq3-int-uns.csv"), true);
		fw.append(buildHeader("rq3uns"));
		for (int i = 0; i < NUM_MODEL; i++)
		{
			for (int j = 0; j < NUM_TECHNIQUES; j++)
			{
				sum += rq2table[i][j];
			}
			auc = rq2table[i][NUM_TECHNIQUES];
			mean = sum/NUM_TECHNIQUES;
			median = findMedian(rq2table[i]);
			String [] temp = br.readLine().split(",");
			fw.append(buildEntry(datasetName, temp[1], mean, median, auc));

			sum = 0;
		}
		
		fw.close();
		br.close();
	}
	
	
	public static void processRQ2final(File f) throws IOException
	{
		FileWriter fwF = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/RQ2-final.csv"), true);
		double [][] table = buildTable(f);
		
		String name = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("_")-2);
		double [] valA = findBest(table);
		
		fwF.append(buildEntry(name, valA));
		fwF.close();
	}
	
	public static void processRQ2FinalRanked()
	{
		boolean header = true;
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File("/home/jacky/weka/Analyzed-Results/RQ2-final.csv")));
			FileWriter fwFR = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/RQ2-final-ranked.csv"), true);
			System.out.println("== RQ 2 final ranked ===");
			while(br.ready())
			{
				if(header)
				{
					String head = br.readLine();
					fwFR.write(head + "\n");
					header = false;
				}
				else
				{
					String [] temp = br.readLine().split(",");
					String dataSetName = temp[0];
					ArrayList<String> nums = new ArrayList<String>();
					for (int i = 1; i < temp.length; i++)
					{
						if (!nums.contains(temp[i]))
						{
							nums.add(temp[i]);
						}
					}
					
					Collections.sort(nums, new Comparator<String>() {
						@Override
						public int compare(String A, String B) {
							double dA = Double.valueOf(A);
							double dB = Double.valueOf(B);
							
							if (dA > dB)
							{
								return -1;
							}
							else if (dA < dB)
							{
								return 1;
							}
							return 0;
						}
						});
					
					fwFR.write(dataSetName);
					for (int j = 1; j < temp.length; j++)
					{
						int rank = nums.indexOf(temp[j]) + 1;
						fwFR.write("," + rank);
					}
					fwFR.write("\n");
				}
			}
			
			br.close();
			fwFR.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	
	public static String [][] fillBestTechniqueTable(File [] rq3files, int numDatasets) throws IOException
	{
		String [][] bestTechniqueTable = new String [numDatasets][4];
		ArrayList<String> techniques = new ArrayList<String>();
		int currInd = 0;
		
		for (File f : rq3files)
		{
			String datasetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("_")-2);
			if (!techniques.contains(datasetName))
			{
				techniques.add(datasetName);
			}
			
			currInd = techniques.indexOf(datasetName);
			bestTechniqueTable [currInd][0] = datasetName;
			if (f.getName().contains("_A_"))
			{
				//index 1
				bestTechniqueTable [currInd][1] = findBest(f);
			}
			else if (f.getName().contains("_P_"))
			{
				//index 2
				bestTechniqueTable [currInd][2] = findBest(f);

			}
			else if (f.getName().contains("_R_"))
			{
				//index 3
				bestTechniqueTable [currInd][3] = findBest(f);

			}
		}
		
		FileWriter fw = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/RQ3-int-best.csv"), true);
		fw.append(buildHeader("rq3intbest"));
		for (String [] Row : bestTechniqueTable)
		{
			fw.append(buildEntry(Row));
		}
		fw.close();
		
		return bestTechniqueTable;
	}
	
	public static void processRQ3final(File f, String [][] bestTechniqueTable) throws IOException
	{
		FileWriter fw = new FileWriter(new File("/home/jacky/weka/Analyzed-Results/RQ3-final.csv"), true);
		BufferedReader br = new BufferedReader(new FileReader(f));
		int bestMeanInd = 0, bestMedianInd =0, currInd = 0;
		double bestMean = 0.0, bestMedian = 0.0;
		boolean header = true;
		String datasetName = "";
		double [] AUC = new double [NUM_MODEL];
		
		while(br.ready())
		{
			String [] temp = br.readLine().split(",");
			if (header)
			{
				header = false;
			}
			else if (!header)
			{
				datasetName = temp[0];
				double currMean = Double.valueOf(temp[2]);
				double currMedian = Double.valueOf(temp[3]);
				AUC[currInd] = Double.valueOf(temp[4]);
				if (currMean > bestMean)
				{
					bestMean = currMean;
					bestMeanInd = currInd;
				}
				if (currMedian > bestMedian)
				{
					bestMedian = currMedian;
					bestMedianInd = currInd;
				}
				currInd++;
			}
		}
		
		fw.append(buildEntry(datasetName, AUC[bestMeanInd], AUC[bestMedianInd], findBestAUC(datasetName, bestTechniqueTable)));
		
		fw.close();
		br.close();
	}
	
	public static double[][] buildTable(File f) throws IOException
	{
		System.out.println(f.toString());
		double [][] table = new double[NUM_MODEL][NUM_TECHNIQUES+1];
		BufferedReader br = new BufferedReader(new FileReader(f));
		boolean header = true;
		int row = 0;
		
		while (row < NUM_MODEL)
		{
			String [] temp = br.readLine().split(",");
			if (header)
			{
				header = false;
			}
			else if (!header)
			{
				for (int i = 0, j = 2; i<NUM_TECHNIQUES+1; i++, j++)
				{
					table[row][i] = Double.valueOf(temp[j]);
				}
				row++;
			}
		}	
		
		br.close();
		return table;
	}
	
	public static String findBest(File f) throws IOException
	{
		String [][] table = new String[NUM_MODEL+1][NUM_TECHNIQUES+2];
		double [][] valTable = buildTable(f);
		BufferedReader br = new BufferedReader(new FileReader(f));
		int row = 0, bestTechCol = 0;
		double best = 0.0, val = 0.0;
		int [] bestValInd = new int [NUM_TECHNIQUES];
		ArrayList<Integer> sameVals = new ArrayList<Integer>();
		
		while (row < NUM_MODEL)
		{
			String [] temp = br.readLine().split(",");
			for (int i = 0, j = 1; i<NUM_TECHNIQUES+2; i++, j++)
			{
				table[row][i] = temp[j];
			}
			row++;
		}	
		br.close();
		
		bestValInd = findBestIndex(valTable);
		for(int i = 0; i<bestValInd.length; i++)
		{
			val = valTable[bestValInd[i]][NUM_TECHNIQUES];
			
			if (val > best) 
			{
				best = val;
				bestTechCol = i;
				if (sameVals.isEmpty()) {
					sameVals.add(i);
				}
				else
				{
					sameVals.clear();
					sameVals.add(i);
				}
			}
			else if (val == best)
			{
				sameVals.add(i);
			}
		}
		
		//collision check for max value 
		if (sameVals.size() != 0)
		{
			int horizontal = 0;
			double tempBest = 0.0;
			for (int i =0; i<NUM_MODEL; i++)
			{
				if (valTable[i][sameVals.get(0)] > tempBest)
				{
					tempBest = valTable[i][sameVals.get(0)];
					horizontal = i;
				}
			}
			tempBest = 0.0;
			for (Integer i : sameVals)
			{
				if (valTable[horizontal][i] > tempBest)
				{
					tempBest = valTable[horizontal][i];
					bestTechCol = i;
				}
			}
		}
		return table[0][bestTechCol+1];
	}
	
	public static double [] findBest(double [][] table)
	{
		double [] temp = new double [NUM_TECHNIQUES];
		double tempBest = 0, choose = 0;
		int tech = 0;
		for (int i = 0; i < NUM_TECHNIQUES; i++)
		{
			for (int j = 0; j < NUM_MODEL; j++)
			{
				if (table[j][i] > tempBest)
				{
					tempBest = table[j][i];
					choose = table[j][NUM_TECHNIQUES];
				}
			}
			temp[tech++] = choose;
			tempBest= 0;
		}
		return temp;
	}
	
	public static int [] findBestIndex(double [][] table)
	{
		int [] temp = new int [NUM_TECHNIQUES];
		double tempBest = 0;
		int ind = 0;
		int tech = 0;
		for (int i = 0; i < NUM_TECHNIQUES; i++)
		{
			for (int j = 0; j < NUM_MODEL; j++)
			{
				if (table[j][i] > tempBest)
				{
					tempBest = table[j][i];
					ind = j;
				}
			}
			temp[tech++] = ind;
			tempBest= 0;
		}
		return temp;
	}
	
	public static double findBestAUC(String datasetName, String [][] bestTechniqueTable) throws IOException
	{
		double auc = 0.0, tempBest = 0.0;
		int row = 0, col = 0;
		String tech = "";
		String [][] table = new String[NUM_MODEL+1][NUM_TECHNIQUES+1];
		BufferedReader br = new BufferedReader(new FileReader(new File("/home/jacky/weka/Analyzed-Results/rq2-int/" + datasetName + "_A_Rq2-int.csv")));
		
		while (row <= NUM_MODEL)
		{
			String [] temp = br.readLine().split(",");
			for (int i = 0, j = 2; i<NUM_TECHNIQUES+1; i++, j++)
			{
				table[row][i] = temp[j];
			}
			row++;
		}	
		br.close();
		
		for (int i = 0; i <bestTechniqueTable.length; i++)
		{
			if (bestTechniqueTable[i][0].equals(datasetName))
			{
				tech = bestTechniqueTable[i][1];
			}
		}
		
		for (int j = 0; j < NUM_TECHNIQUES; j++)
		{
			if (table[0][j].equals(tech))
			{
				col = j;
			}
		}
		
		for (int k = 1; k<=NUM_MODEL; k++)
		{
			if (Double.valueOf(table[k][col]) > tempBest)
			{
				tempBest = Double.valueOf(table[k][col]);
				auc = Double.valueOf(table[k][NUM_TECHNIQUES]);
			}
		}
		
		return auc;
	}
	public static dataPoint findDP(ArrayList<dataPoint>dpl, dataPoint target)
	{
		dataPoint temp = null;
		//System.out.println("TARGET: " + target);
		for (dataPoint dp : dpl)
		{
			//System.out.println(dp);
			if (dp.datasetName.toLowerCase().equals(target.datasetName.toLowerCase()) 
					&& dp.Model.toLowerCase().equals(target.Model.toLowerCase()))
			{
				//System.out.println(dp);
				return dp;
			}
		}
		return temp;
	}
	
	public static String buildHeader(String type)
	{
		StringBuilder header = new StringBuilder();
		
		header.append("Dataset");
		header.append(',');
		if (type == "rq2int" || type == "rq3int" || type == "rq3uns")
		{
			header.append("Model");
			header.append(',');
		}
		
		if (type != "rq3uns" && type != "rq3final" && type != "rq3intbest")
		{
			for (String t : listOfTechniques)
			{
				header.append(t);
				header.append(',');
			}
		}
		else if (type == "rq3uns" || type == "rq3final")
		{
			header.append("Mean of Techniques");
			header.append(',');
			header.append("Median of Techniques");
			header.append(',');
		}
		else if (type == "rq3intbest")
		{
			header.append("Best Technique AUC");
			header.append(',');
			header.append("Best Technique Precision");
			header.append(',');
			header.append("Best Technique Recall");
		}
		
		if (type == "rq2int" || type == "rq3uns")
		{
			header.append("ActualAccuracy");
		}
		else if (type == "rq3int")
		{
			header.append("Model Accuracy on D");
		}
		else if (type == "rq3final")
		{
			header.append("Best");
		}
		header.append('\n');
		
		return header.toString();
	}
	
	public static String buildEntry(dataPoint dp, double [] vals, double actual)
	{
		StringBuilder entry = new StringBuilder();
		
		entry.append(dp.datasetName);
		entry.append(',');
		entry.append(dp.Model);
		entry.append(',');
		for (double v : vals)
		{
			entry.append(v);
			entry.append(',');
		}
		entry.append(actual);
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static String buildEntry(String name, double [] vals)
	{
		StringBuilder entry = new StringBuilder();
		
		entry.append(name);
		for (double v : vals)
		{
			entry.append(',');
			entry.append(v);
		}
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static String buildEntry(String ds, String model, double mean, double median, double actual)
	{
		StringBuilder entry = new StringBuilder();
		
		entry.append(ds);
		entry.append(',');
		entry.append(model);
		entry.append(',');
		entry.append(mean);
		entry.append(',');
		entry.append(median);
		entry.append(',');
		entry.append(actual);
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static String buildEntry(String ds, double bestMean, double bestMedian, double best)
	{
		StringBuilder entry = new StringBuilder();
		
		entry.append(ds);
		entry.append(',');
		entry.append(bestMean);
		entry.append(',');
		entry.append(bestMedian);
		entry.append(',');
		entry.append(best);
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static String buildEntry(String [] data)
	{
		StringBuilder entry = new StringBuilder();
		
		for(String d : data)
		{
			entry.append(d);
			entry.append(",");
		}
		entry.append('\n');
		
		return entry.toString();
	}
	
	public static double findMedian(double [] vals)
	{
		Arrays.sort(vals);
		int mid = vals.length/2;
		
		if (vals.length%2 == 0)
		{
			return (vals[mid] + vals[mid+1])/2;
		}
		else
		{
			return vals[mid];
		}
	}
	
	private static void clearFiles()
	{
		File [] rq2int = new File ("/home/jacky/weka/Analyzed-Results/rq2-int/").listFiles();
		File [] rq3int = new File ("/home/jacky/weka/Analyzed-Results/rq3-int/").listFiles();
		File [] rq3uns = new File ("/home/jacky/weka/Analyzed-Results/rq3-uns/").listFiles();
		
		for (File f : rq2int)
		{
			f.delete();
		}
		for (File f : rq3int)
		{
			f.delete();
		}
		for (File f : rq3uns)
		{
			f.delete();
		}
		
		File file = new File("/home/jacky/weka/Analyzed-Results/RQ2-final.csv");
        file.delete();
        file = new File("/home/jacky/weka/Analyzed-Results/RQ2-final-ranked.csv");
        file.delete();
        file = new File("/home/jacky/weka/Analyzed-Results/RQ3-final.csv");
        file.delete();
        file = new File("/home/jacky/weka/Analyzed-Results/RQ3-int-best.csv");
        file.delete();
	}
	
	public static class dataPoint implements Comparable<dataPoint>
	{
		public String datasetName;
		public double auc;
		public double precision;
		public double recall;
		public String Model;
		public String technique;
		
		public dataPoint(String dn, String model, String tech, double auc, double pre, double rec)
		{
			this.datasetName = dn;
			Model = model;
			technique = tech;
			this.auc = auc;
			precision = pre;
			recall = rec;
		}
		
		public dataPoint(String dn, String model, double auc, double pre, double rec)
		{
			this.datasetName = dn;
			Model = model;
			this.auc = auc;
			precision = pre;
			recall = rec;
		}
		
		public boolean equal(Object o)
		{
			if (o == this)
			{
				return true;
			}
			
			dataPoint dp = (dataPoint) o;
			
			return dp.datasetName.equals(this.datasetName) &&
					dp.Model.equals(this.Model) &&
					dp.auc == this.auc &&
					dp.precision == this.precision &&
					dp.recall == this.recall;
		}
		
		public String toString()
		{
			return "Dataset: " + this.datasetName 
					+ " Model: " + this.Model
					+ " Technique: " + this.technique
					+ " AUC: " + this.auc
					+ " Precision: " + this.precision
					+ " Recall: " + this.recall;
		}
		
		@Override
		public int compareTo(dataPoint o) {
			// TODO Auto-generated method stub
			String name = datasetName.substring(0, datasetName.lastIndexOf("_"));
			String nameOther = o.datasetName.substring(0, o.datasetName.lastIndexOf("_"));
			Integer num = Integer.valueOf(datasetName.substring(datasetName.lastIndexOf("_")+1));
			Integer numOther = Integer.valueOf(o.datasetName.substring(o.datasetName.lastIndexOf("_")+1));

			if (datasetName.compareTo(nameOther) == 0)
			{
				return num.compareTo(numOther);
			}
			return name.compareTo(nameOther);
		}
	}
	
}
