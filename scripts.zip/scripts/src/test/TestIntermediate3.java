package test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;

import logic.Intermediate3;
import logic.RQ2;
import logic.TechniqueRes;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.CSVLoader;

public class TestIntermediate3 {
	
	private Instances getData(File f) throws IOException
	{
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(f);
		Instances data = csvload.getDataSet();
		
		return data;
	}
	
	private boolean checkData(Instances A, Instances B)
	{
		if (A.numInstances() != B.numInstances())
		{
			return false;
		}
		else
		{
			for(int i = 0; i < A.numInstances(); i++)
			{
				if(!A.get(i).toString().equals(B.get(i).toString()))
				{
					return false;
				}
			}
		}
		return true;
	}
	
	@Test
	public void test_findAverage()
	{
		double [] vals = {1.0, 2.0, 3.0, 4.0, 5.0};
		
		assertEquals(3.0, Intermediate3.findAverage(vals, 5), 0.0);
	}
	
	@Test
	public void test_isSame() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instance A = data.get(5);
		
		assertTrue(Intermediate3.isSame(A, data.get(5)));
	}
	
	@Test
	public void test_contains() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instance A = data.get(5);
		
		assertTrue(Intermediate3.contains(data, A));
	}
	
	@Test
	public void test_outOfSampleData() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances train = Intermediate3.seperateDataset(data, "1011", true);
		Instances test = Intermediate3.seperateDataset(data, "1011", false);
		Instances newTest = Intermediate3.outOfSampleData(data, train);
		
		assertTrue(checkData(test, newTest));
	}
	
	@Test
	public void test_findNumVersions() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		ArrayList<String> versions = new ArrayList<String>();
		versions.add("100");
		versions.add("102");
		versions.add("104");
		versions.add("107");
		versions.add("1011");
		
		assertEquals(versions, Intermediate3.findNumVersions(data));
	}
	
	@Test
	public void test_findPositiveClassIndex() throws IOException 
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		assertEquals(1, Intermediate3.findPositiveClassIndex(data));
	}
	
	@Test
	public void test_seperateDataset_train() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances train = Intermediate3.seperateDataset(data, "1011", true);
		
		boolean checked = true;
		for (Instance i : train)
		{
			if (i.toString(0).equals("1011"))
			{
				checked = false;
				break;
			}
		}
		assertTrue(checked);
	}
	
	@Test
	public void test_seperateDataset_test() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances test = Intermediate3.seperateDataset(data, "1011", false);
		
		boolean checked = true;
		for (Instance i : test)
		{
			if (!i.toString(0).equals("1011"))
			{
				checked = false;
				break;
			}
		}
		assertTrue(checked);
	}
	
	@Test
	public void test_buildHeader() 
	{
		assertEquals("Dataset,Model,Technique,AUC,Precision,Recall\n", Intermediate3.buildHeader());
	}
	
	@Test
	public void test_buildEntry() throws Exception
	{
		assertEquals("Keymind-B,RandomForest,Holdout 0.5,1.1,1.2,1.3\n", Intermediate3.buildEntry("Keymind-B", "RandomForest", "Holdout 0.5", 1.1, 1.2, 1.3));
	}
	
	@Test
	public void test_removeAttribute() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		data = Intermediate3.removeAttribute(data);
		
		assertEquals("3,0,1,1,14,7,7,14,7,7,18,7,6,25,?,2,14,2,0,15,43,43,98,FALSE", data.get(0).toString());
	}
	
	@Test
	public void test_findLastRelease() throws IOException
	{
		File f = new File("/home/jacky/eclipse-workspace/SURP/TestResources/ant.csv");
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(f);
		Instances data = csvload.getDataSet();
		
		assertEquals("1.7", Intermediate3.findLastRelease(data));
	}
	
	@Test
	public void test_csv2arff () throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));

		Intermediate3.csv2arff(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"), false);
		Instances newData = new Instances(new FileReader("/home/jacky/weka/modifiedDatasets/Keymind-B.arff"));

		assertTrue(checkData(data, newData));
	}
	
	@Test
	public void test_csv2arff_special () throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/poi.csv"));

		Intermediate3.csv2arff(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/poi.csv"), true);
		Instances newData = new Instances(new FileReader("/home/jacky/weka/modifiedDatasets/poi.arff"));

		assertTrue(checkData(data, newData));
	}
	
	private boolean checkBest(double [] A, double [] B)
	{
		for(int i = 0; i<A.length; i++)
		{
			if(A[i] != B[i])
			{
				return false;
			}
		}
		return true;
	}
	@Test
	public void test_findBestValues()
	{
		ArrayList<TechniqueRes> res = new ArrayList<TechniqueRes>();
		double [] best = new double [3];
		double [] bestRef = {1.0, 2.0, 3.0};

		TechniqueRes A = new TechniqueRes(1.0, 1.0, 1.0);
		TechniqueRes B = new TechniqueRes(1.0, 2.0, 3.0);
		
		res.add(A);
		res.add(B);
		
		Intermediate3.findBestValues(res, best);
		
		assertTrue(checkBest(bestRef, best));
	}

}