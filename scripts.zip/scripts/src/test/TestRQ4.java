package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;

import logic.RQ4;

public class TestRQ4 {

	@Test
	public void test_findTechniqueInd()
	{
		String src = "2-fold";
		
		assertEquals(4, RQ4.findTechniqueInd(src));
	}
	
	
	@Test
	public void test_calcAverage()
	{
		double [] vals = {1.0, 2.0, 3.0, 4.0, 5.0};
		
		assertEquals(3.0, RQ4.calcAverage(vals, 5), 0.0);
	}
	
	@Test
	public void test_buildEntry1()
	{
		assertEquals("Keymind-B,0.124,0.421\n", RQ4.buildEntry("Keymind-B", 0.124, 0.421));
	}

	@Test
	public void test_buildEntry2()
	{
		assertEquals("Keymind-B,Holdout 0.5,test,another\n", RQ4.buildEntry("Keymind-B", "Holdout 0.5", "test", "another"));
	}
	
	@Test
	public void test_buildEntry3()
	{
		assertEquals("Keymind-B,Holdout 0.5,0.421\n", RQ4.buildEntry("Keymind-B", "Holdout 0.5", 0.421));
	}
	
	@Test
	public void test_buildEntry4()
	{
		assertEquals("Keymind-B,Holdout 0.5,0.124,0.421,0.234\n", RQ4.buildEntry("Keymind-B", "Holdout 0.5", 0.124, 0.421, 0.234));
	}
	
	@Test
	public void test_buildHeader1()
	{
		assertEquals("Dataset,Techniques,AUC bias,Precision bias,Recall bias\n", RQ4.buildHeader("computeBias"));
	}
	
	@Test
	public void test_buildHeader2()
	{
		assertEquals("Dataset,Techniques,Rank on Bias\n", RQ4.buildHeader("biasOrder"));
	}
	
	@Test
	public void test_buildHeader3()
	{
		assertEquals("Dataset,Techniques,Rank Bias Order,Rank Actual Order\n", RQ4.buildHeader("order"));
	}
	
	@Test
	public void test_buildHeader4()
	{
		assertEquals("Dataset,AUC selected by best technique,AUC selected by lowest bias\n", RQ4.buildHeader("lossAUC"));
	}
	
	@Test
	public void test_buildTable() throws IOException
	{
		String tableString = "[[0.968, 0.963, 0.93, 0.986, 0.87, 0.0, 0.0, 0.975, 0.964, 0.965, 0.969, 0.898, 0.946], "
				+ "[0.797, 0.866, 0.843, 0.897, 0.759, 0.0, 0.0, 0.907, 0.832, 0.907, 0.819, 0.645, 0.902], "
				+ "[0.867, 0.871, 0.886, 0.898, 0.932, 0.0, 0.0, 0.885, 0.875, 0.853, 0.882, 0.856, 0.819], "
				+ "[0.767, 0.836, 0.853, 0.893, 0.232, 0.0, 0.0, 0.898, 0.766, 0.842, 0.9, 0.531, 0.923], "
				+ "[0.805, 0.843, 0.808, 0.872, 0.752, 0.0, 0.0, 0.837, 0.795, 0.823, 0.81, 0.734, 0.916], "
				+ "[0.768, 0.845, 0.773, 0.847, 0.745, 0.0, 0.0, 0.802, 0.773, 0.813, 0.817, 0.698, 0.916], "
				+ "[0.781, 0.756, 0.748, 0.817, 0.63, 0.0, 0.0, 0.785, 0.789, 0.772, 0.787, 0.798, 0.605], "
				+ "[0.841, 0.819, 0.863, 0.862, 0.876, 0.0, 0.0, 0.857, 0.841, 0.784, 0.859, 0.856, 0.876], "
				+ "[0.799, 0.832, 0.818, 0.845, 0.832, 0.0, 0.0, 0.856, 0.847, 0.826, 0.85, 0.787, 0.787]]";

		double [][] res = RQ4.buildTable(new File("/home/jacky/weka/Analyzed-Results/rq2-int/Keymind-B_3_A_Rq2-int.csv"));
		assertEquals(tableString, Arrays.deepToString(res));
	}
	
	@Test
	public void test_getActualOrder() throws IOException
	{
		ArrayList<RQ4.dataPoint> res = new ArrayList<RQ4.dataPoint>();
		
		res.add(new RQ4.dataPoint("0.632 Bootstrap", 0.946));
		res.add(new RQ4.dataPoint("Holdout 0.5", 0.946));
		res.add(new RQ4.dataPoint("Holdout 0.7", 0.946));
		res.add(new RQ4.dataPoint("Leave-one-release-out", 0.946));
		res.add(new RQ4.dataPoint("Optimism-reduced", 0.946));
		res.add(new RQ4.dataPoint("Ordinary", 0.946));
		res.add(new RQ4.dataPoint("Repeated Holdout 0.5", 0.946));
		res.add(new RQ4.dataPoint("Repeated Holdout 0.7", 0.946));
		res.add(new RQ4.dataPoint("out-of-sample", 0.946));
		res.add(new RQ4.dataPoint("10-fold", 0.819));
		res.add(new RQ4.dataPoint("10x10-fold", 0.819));
		res.add(new RQ4.dataPoint("2-fold", 0.819));

		assertTrue(checkedList(res, RQ4.getActualOrder("Keymind-B_3")));
	}
	
	private boolean checkedList(ArrayList<RQ4.dataPoint> A, ArrayList<RQ4.dataPoint> B)
	{
		if (A.size() != B.size())
		{
			System.out.println("size problem");
			return false;
		}
		else
		{
			for (int i = 0; i < A.size(); i++)
			{
				if (!A.get(i).equals(B.get(i)))
				{
					return false;
				}
			}
		}
		return true;
	}
	
	@Test
	public void test_best_bias() throws IOException
	{
		String [] data = {"Keymind-B_3", "0.946", "0.946", "0.946",	"0.946", "0.819", "0.819", "0.819", "0.946", "0.946", "0.946", "0.946", "0.946"};
		boolean bias = true;
		
		assertEquals(0.946, RQ4.best(data, bias), 0.1);
	}
	
	@Test
	public void test_best() throws IOException
	{
		String [] data = {"Keymind-B_3", "0.946", "0.946", "0.946",	"0.946", "0.819", "0.819", "0.819", "0.946", "0.946", "0.946", "0.946", "0.946"};
		boolean bias = false;
		
		assertEquals(0.946, RQ4.best(data, bias), 0.1);
	}
}
