package test;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import logic.InstancesSet;
import logic.RQ1;
import logic.RQ2;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.trees.RandomForest;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;

import org.junit.Test;

public class TestRQ2 {
	
	private Instances getData(File f) throws IOException
	{
		//File f = new File("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv");
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(f);
		Instances data = csvload.getDataSet();
		
		return data;
	}
	
	private Evaluation getEvaluation(Instances train, Instances test, Classifier c) throws Exception
	{
		Evaluation e = new Evaluation(train);
		e.evaluateModel(c, test);
		return e;
	}

	@Test
	public void test_findLastRelease() throws IOException
	{
		File f = new File("/home/jacky/eclipse-workspace/SURP/TestResources/ant.csv");
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(f);
		Instances data = csvload.getDataSet();
		
		assertEquals("1.7", RQ2.findLastRelease(data));
	}
	
	@Test
	public void test_buildHeader() 
	{
		assertEquals("Dataset,Model,Technique,AUC,Precision,Recall\n", RQ2.buildHeader());
	}
	
	@Test
	public void test_findPositiveClassIndex() throws IOException 
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		assertEquals(1, RQ2.findPositiveClassIndex(data));
	}
	
	@Test
	public void test_buildEntry() throws Exception
	{
		assertEquals("Keymind-B,RandomForest,Holdout 0.5,1.1,1.2,1.3\n", RQ2.buildEntry("Keymind-B", "RandomForest", "Holdout 0.5", 1.1, 1.2, 1.3));
	}
	
	@Test
	public void test_removeAttribute() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		data = RQ2.removeAttribute(data);
		
		assertEquals("3,0,1,1,14,7,7,14,7,7,18,7,6,25,?,2,14,2,0,15,43,43,98,FALSE", data.get(0).toString());
	}
	
	@Test
	public void test_findAverage()
	{
		double [] vals = {1.0, 2.0, 3.0, 4.0, 5.0};
		
		assertEquals(3.0, RQ2.findAverage(vals, 5), 0.0);
	}
	
	@Test
	public void test_isSame() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instance A = data.get(5);
		
		assertTrue(RQ2.isSame(A, data.get(5)));
	}
	
	@Test
	public void test_contains() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instance A = data.get(5);
		
		assertTrue(RQ2.contains(data, A));
	}
	
	@Test
	public void test_outOfSampleData() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances train = RQ2.seperateDataset(data, "1011", true);
		Instances test = RQ2.seperateDataset(data, "1011", false);
		Instances newTest = RQ2.outOfSampleData(data, train);
		
		assertTrue(checkDataSimple(test, newTest));
	}
	
	@Test
	public void test_findNumVersions() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		ArrayList<String> versions = new ArrayList<String>();
		versions.add("100");
		versions.add("102");
		versions.add("104");
		versions.add("107");
		versions.add("1011");
		
		assertEquals(versions, RQ2.findNumVersions(data));
	}
	
	@Test
	public void test_seperateDataset_train() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances train = RQ2.seperateDataset(data, "1011", true);
		
		boolean checked = true;
		for (Instance i : train)
		{
			if (i.toString(0).equals("1011"))
			{
				checked = false;
				break;
			}
		}
		assertTrue(checked);
	}
	
	@Test
	public void test_seperateDataset_test() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances test = RQ2.seperateDataset(data, "1011", false);
		
		boolean checked = true;
		for (Instance i : test)
		{
			if (!i.toString(0).equals("1011"))
			{
				checked = false;
				break;
			}
		}
		assertTrue(checked);
	}
	
	private boolean checkDataSimple(Instances A, Instances B)
	{
		if (A.numInstances() != B.numInstances())
		{
			System.out.println("size failed");
			return false;
		}
		else
		{
			for(int i = 0; i < A.numInstances(); i++)
			{
				if(!A.get(i).toString().equals(B.get(i).toString()))
				{
					System.out.println("equals failed at " + i);
					System.out.println(A.get(i).toString());
					System.out.println(B.get(i).toString());
					return false;
				}
			}
		}
		return true;
	}
	
	@Test
	public void test_csv2arff () throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));

		RQ2.csv2arff(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances newData = new Instances(new FileReader("/home/jacky/weka/modifiedDatasets/Keymind-B.arff"));

		assertTrue(checkDataSimple(data, newData));
	}
	
	@Test
	public void test_csv2arff_special () throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/poi.csv"));

		RQ2.csv2arff(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/poi.csv"), true);
		Instances newData = new Instances(new FileReader("/home/jacky/weka/modifiedDatasets/poi.arff"));

		assertTrue(checkDataSimple(data, newData));
	}
	
}
